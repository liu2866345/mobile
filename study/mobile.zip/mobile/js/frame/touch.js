/**
 * Created by LIUD009 on 2015/12/8.
 * listen touch left right
 * drag-left right
 */
;(function($,undefined){
    var Positon = function(){
        this.start={x:0,y:0};
        this.end={x:0,y:0};
        this.click = false;//是否点击中 false不是点击
    };

    $.fn.extend({
        moveLR:function(forward,funClall){
            var tempPostion = new Positon();
            $(this).unbind(".liudl");//avoid repeat bind
            $(this).unbind(".drag");
            $(this).bind("touchstart.liudl",function(event){
                event.stopPropagation();
                //console.log("touchstart...");
                tempPostion.start.x = event.originalEvent.targetTouches[0].pageX;
                tempPostion.start.y = event.originalEvent.targetTouches[0].pageY;
                //drag relative
                forward=="drag"?tempPostion.click = true:tempPostion.click = false;//拖动开始
                $("#log").append("touch start ...");
                event.preventDefault()
            });
            $(this).bind("touchmove.liudl",function(event){
                event.stopPropagation();
                if(event.originalEvent.targetTouches.length==1){//one figure
                    var endp = event.originalEvent.targetTouches[0];
                    tempPostion.end.x = endp.pageX;
                    tempPostion.end.y = endp.pageY;
                    //drag move...
                    tempPostion.click?funClall(endp.pageX, endp.pageY):console.log("drag over...");//while drag then active
                }
                console.log("movover this = "+$(this).attr("class"));
                $("#log").append("moving.......");
                event.preventDefault()
            });
            $(this).bind("touchend.liudl",function(event){
                $("#log").append("end.......tempPostion.click = "+tempPostion.click);
                if(tempPostion.click){
                    tempPostion.click = false;//drag over
                    return;
                }
                tempPostion.end.x-tempPostion.start.x>10?$(this).trigger("right"):"";//trigger forward left or right
                tempPostion.end.x-tempPostion.start.x<-10?$(this).trigger("left"):"";
                $("#log").append("end.......");
                event.stopPropagation();
                event.preventDefault();
            });
            $(this).bind(forward,funClall);
            return this;
        }
    });
})(jQuery);